package mosh.bo.msappsjsonproject.ui.movieList;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

import mosh.bo.msappsjsonproject.models.Movie;
import mosh.bo.msappsjsonproject.models.RoomDataSource;

public class MovieListViewModel extends AndroidViewModel {
    // TODO: Implement the ViewModel
    LiveData<List<Movie>> movies;
    RoomDataSource ds;

    public MovieListViewModel(@NonNull Application application) {
        super(application);

        ds = new RoomDataSource(getApplication());
        movies = ds.getMovies();
    }
    public List<Movie> getMovies(List<Movie> movies){
        for (int i = 0; i < movies.size(); i++) {
            Movie movie = movies.get(i);
            for (int j = i; j < movies.size(); j++) {
                if(movie.getReleaseYear() < movies.get(j).getReleaseYear()){
                    movie = movies.remove(j);
                    movies.add(i, movie);
                }
            }

        }
        return movies;
    }


}