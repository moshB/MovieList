package mosh.bo.msappsjsonproject.models;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.room.Room;

import java.util.List;

public class RoomDataSource {

    private MovieDatabase db;

    public RoomDataSource(Context context) {
        db = Room.databaseBuilder(context, MovieDatabase.class, "MovieDatabase").build();
    }

    public void add(Movie movie) {
        new Thread(() -> {
            db.getDao().add(movie);
        }).start();
    }

    public void add(Movie[] movies) {
        new Thread(() -> {
            db.getDao().add(movies);
        }).start();
    }

    public LiveData<List<Movie>> getMovies() {
        return db.getDao().getMovies();
    }

}
