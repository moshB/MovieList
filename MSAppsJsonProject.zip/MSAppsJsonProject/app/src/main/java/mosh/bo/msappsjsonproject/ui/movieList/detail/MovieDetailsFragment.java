package mosh.bo.msappsjsonproject.ui.movieList.detail;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import mosh.bo.msappsjsonproject.R;
import mosh.bo.msappsjsonproject.models.Movie;


public class MovieDetailsFragment extends Fragment {

    ImageView ivMovie;
    TextView tvTitle;
    TextView tvYear;
    TextView tvRating;
    TextView tvGenre;
    Movie movie;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_movie_detils, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ivMovie = view.findViewById(R.id.ivMovieDetail);
        tvTitle = view.findViewById(R.id.tvTitleDetail);
        tvYear = view.findViewById(R.id.tvYearDetail);
        tvRating = view.findViewById(R.id.tvRatingDetail);
        tvGenre = view.findViewById(R.id.tvGenreDetail);
        Bundle bundle = getArguments();
        movie = bundle.getParcelable("movie");
        paintDetails();
    }

    void paintDetails() {
        Picasso.get().load(movie.getImage()).into(ivMovie);
        tvTitle.setText(movie.getTitle());
        tvYear.setText(String.valueOf(movie.getReleaseYear()));
        tvGenre.setText(movie.getGenre());
        tvRating.setText("Rating: " + movie.getRating());
    }
}