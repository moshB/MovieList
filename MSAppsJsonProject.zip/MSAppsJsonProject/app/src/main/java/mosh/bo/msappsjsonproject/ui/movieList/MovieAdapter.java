package mosh.bo.msappsjsonproject.ui.movieList;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import mosh.bo.msappsjsonproject.R;
import mosh.bo.msappsjsonproject.models.Movie;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder> {
    List<Movie> movies;

    public MovieAdapter(List<Movie> movies) {
        this.movies = movies;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Movie movie = movies.get(position);
        holder.tvTitle.setText(movie.getTitle());
        holder.tvReleaseYear.setText(String.valueOf(movie.getReleaseYear()));
        Picasso.get().load(movie.getImage()).into(holder.ivMovie);
        holder.itemView.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putParcelable("movie", movie);
            Navigation.findNavController(v).navigate(R.id.action_movieListFragment_to_movieDetilsFragment, bundle);
        });
    }

    @Override
    public int getItemCount() {
        return movies.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivMovie;
        TextView tvTitle;
        TextView tvReleaseYear;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvReleaseYear = itemView.findViewById(R.id.tvReleaseYear);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            ivMovie = itemView.findViewById(R.id.ivMovie);
        }
    }
}
