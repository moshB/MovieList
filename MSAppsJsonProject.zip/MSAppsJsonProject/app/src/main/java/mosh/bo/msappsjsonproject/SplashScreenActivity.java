package mosh.bo.msappsjsonproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;

import android.content.Intent;
import android.os.Bundle;

import java.util.List;

import mosh.bo.msappsjsonproject.models.Movie;
import mosh.bo.msappsjsonproject.models.MovieDataSource;
import mosh.bo.msappsjsonproject.models.RoomDataSource;

public class SplashScreenActivity extends AppCompatActivity {

    MutableLiveData<List<Movie>> movies;
    MovieDataSource mDS;
    RoomDataSource rDS;
    LifecycleOwner lO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        rDS = new RoomDataSource(this);
        movies = new MutableLiveData<>();

        lO = () -> SplashScreenActivity.super.getLifecycle();


        rDS.getMovies().observe(lO, movies -> {
            if (movies.size() != 0) goToMovieList(movies);
            else loadData();
        });
    }

    void loadData() {
        mDS = new MovieDataSource();
        mDS.readData(movies);
        movies.observe(lO, movies -> {
            System.out.println(2);
            Movie[] moviesArray = new Movie[movies.size()];
            for (int i = 0; i < movies.size(); i++) {
                moviesArray[i] = movies.get(i);
            }
            rDS.add(moviesArray);
            goToMovieList(movies);
        });
    }

    void goToMovieList(List<Movie> movies) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}