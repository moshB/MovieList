package mosh.bo.msappsjsonproject.ui.movieList;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


import mosh.bo.msappsjsonproject.R;
import mosh.bo.msappsjsonproject.models.RoomDataSource;

public class MovieListFragment extends Fragment {


    RoomDataSource ds;

    private MovieListViewModel mViewModel;

    FloatingActionButton fabAddMovie;


    public static MovieListFragment newInstance() {
        return new MovieListFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.movie_list_fragment, container, false);
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ds = new RoomDataSource(getContext());
        fabAddMovie = view.findViewById(R.id.fabAddMovie);

        RecyclerView rvMovies = view.findViewById(R.id.rvMovies);
        rvMovies.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));

        ds.getMovies().observe(getViewLifecycleOwner(), movies -> {
            movies = mViewModel.getMovies(movies);
            rvMovies.setAdapter(new MovieAdapter(movies));
        });
        fabAddMovie.setOnClickListener(v->{
            Navigation.findNavController(v).navigate(R.id.action_movieListFragment_to_QRFragment);
        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(MovieListViewModel.class);
        // TODO: Use the ViewModel
    }

}