package mosh.bo.msappsjsonproject.models;

import androidx.lifecycle.MutableLiveData;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MovieDataSource {

    List<Movie> movies = new ArrayList<>();
    private String address = "https://api.androidhive.info/json/movies.json";


    public void readData(MutableLiveData<List<Movie>> callback) {

        Request request = new Request.Builder().url(address).build();

        Call call = new OkHttpClient().newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {

            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                String json = response.body().string();

                try {
                    JSONArray arrayMoviesJson = new JSONArray(json);
                    for (int i = 0; i < arrayMoviesJson.length(); i++) {
                        JSONObject movieJson = arrayMoviesJson.getJSONObject(i);
                        String title = movieJson.getString("title");
                        String image = movieJson.getString("image");
                        JSONArray genreArr = movieJson.getJSONArray("genre");
                        String genre = "";
                        int releaseYear = movieJson.getInt("releaseYear");
                        double rating = movieJson.getDouble("rating");

                        for (int j = 0; j < genreArr.length(); j++) {
                            genre = genre + genreArr.getString(j) + ", ";
                        }

                        movies.add(new Movie(title, image, genre, releaseYear, rating));
                    }
                    callback.postValue(movies);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

    }
}
