package mosh.bo.msappsjsonproject.ui.movieList.QR;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.Result;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import mosh.bo.msappsjsonproject.R;
import mosh.bo.msappsjsonproject.models.Movie;
import mosh.bo.msappsjsonproject.models.RoomDataSource;

public class QRFragment extends Fragment {
    RoomDataSource ds;
    private CodeScanner mCodeScanner;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ds = new RoomDataSource(getContext());
        final Activity activity = getActivity();
        View root = inflater.inflate(R.layout.fragment_q_r, container, false);
        CodeScannerView scannerView = root.findViewById(R.id.scanner_view);
        mCodeScanner = new CodeScanner(activity, scannerView);
        mCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull Result result) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        onGetJson(result.getText());
                    }
                });
            }
        });
        scannerView.setOnClickListener(view -> mCodeScanner.startPreview());
        return root;
    }

    private void onGetJson(String jsonString) {
        try {
            JSONObject jsonObject = new JSONObject(jsonString);
            String title = jsonObject.getString("title");
            String image = jsonObject.getString("image");
            double rating = jsonObject.getDouble("rating");
            int releaseYear = jsonObject.getInt("releaseYear");
            JSONArray genreArray = jsonObject.getJSONArray("genre");
            String genre = "";
            for (int i = 0; i < genreArray.length(); i++) {
                genre = genre + genreArray.getString(i);
            }
            Movie movie = new Movie(title, image, genre, releaseYear, rating);
            checkINData(movie);
        } catch (JSONException e) {
            Snackbar.make(this.getView(), "Identification Json fail", Snackbar.LENGTH_LONG)
                    .setAction("action", null).show();
            goToMovies();
        }
    }

    private void checkINData(Movie movie) {

        View view = this.getView();
        ds.getMovies().observe(getViewLifecycleOwner(), movies -> {
            boolean check = false;
            for (Movie movie1 : movies) {
                if (movie.equals(movie1)) {
                    check = true;
                }
            }
            if(check){
                Snackbar.make(view, "Current movie already exist in the Database", Snackbar.LENGTH_LONG)
                        .setAction("action", null).show();
                goToMovies();
            }else {
                ds.add(movie);
                goToMovies();
            }
        });
    }

    private void goToMovies() {
        Navigation.findNavController(this.getView()).navigate(R.id.action_QRFragment_to_movieListFragment);
    }


    @Override
    public void onResume() {
        super.onResume();
        mCodeScanner.startPreview();
    }

    @Override
    public void onPause() {
        mCodeScanner.releaseResources();
        super.onPause();
    }

}